
release_major = 1
release_minor = 11
release_patch = 33
release_so_abi_rev = release_patch

# These are set by the distribution script
release_vc_rev = None
release_datestamp = 0
release_type = 'unreleased'
